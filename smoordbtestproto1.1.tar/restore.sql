--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 9.6.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."character" DROP CONSTRAINT user_id_fkey;
ALTER TABLE ONLY public.character_spellcasting DROP CONSTRAINT spellcasting_description_id_fkey;
ALTER TABLE ONLY public."character" DROP CONSTRAINT race_description_id_fkey;
ALTER TABLE ONLY public.character_production_skill DROP CONSTRAINT production_skill_description_id_fkey;
ALTER TABLE ONLY public.character_general_skill DROP CONSTRAINT general_skill_description_id_fkey;
ALTER TABLE ONLY public.character_combat_action DROP CONSTRAINT combat_action_description_fkey;
ALTER TABLE ONLY public."character" DROP CONSTRAINT class_description_id_fkey;
ALTER TABLE ONLY public.character_production_skill DROP CONSTRAINT character_id_fkey;
ALTER TABLE ONLY public.character_combat_action DROP CONSTRAINT character_id_fkey;
ALTER TABLE ONLY public.character_spellcasting DROP CONSTRAINT character_id_fkey;
ALTER TABLE ONLY public.character_general_skill DROP CONSTRAINT character_id_fkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_id_pkey;
ALTER TABLE ONLY public.spellcasting_description DROP CONSTRAINT spellcasting_primary_key;
ALTER TABLE ONLY public.race_description DROP CONSTRAINT race_description_pkey;
ALTER TABLE ONLY public.production_skill_description DROP CONSTRAINT production_skills_pkey;
ALTER TABLE ONLY public.general_skill_description DROP CONSTRAINT general_skills_pkey;
ALTER TABLE ONLY public.combat_action_description DROP CONSTRAINT combat_actions_pkey;
ALTER TABLE ONLY public.class_description DROP CONSTRAINT class_description_pkey;
ALTER TABLE ONLY public.character_spellcasting DROP CONSTRAINT character_spellcasting_pkey;
ALTER TABLE ONLY public.character_production_skill DROP CONSTRAINT character_production_skills_pkey;
ALTER TABLE ONLY public."character" DROP CONSTRAINT character_pkey;
ALTER TABLE ONLY public.character_general_skill DROP CONSTRAINT character_general_skill_pkey;
ALTER TABLE ONLY public.character_combat_action DROP CONSTRAINT character_combat_actions_pkey;
ALTER TABLE public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.spellcasting_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.race_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.production_skill_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.general_skill_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.combat_action_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.class_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.character_spellcasting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.character_production_skill ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.character_general_skill ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.character_combat_action ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."character" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.user_id_seq;
DROP TABLE public."user";
DROP SEQUENCE public.spellcasting_id_seq;
DROP TABLE public.spellcasting_description;
DROP SEQUENCE public.races_id_seq;
DROP TABLE public.race_description;
DROP SEQUENCE public.production_skills_id_seq;
DROP TABLE public.production_skill_description;
DROP SEQUENCE public.hibernate_sequence;
DROP SEQUENCE public.general_skills_id_seq;
DROP TABLE public.general_skill_description;
DROP SEQUENCE public.combat_actions_id_seq;
DROP TABLE public.combat_action_description;
DROP SEQUENCE public.classes_id_seq;
DROP TABLE public.class_description;
DROP SEQUENCE public.character_spellcasting_id_seq;
DROP TABLE public.character_spellcasting;
DROP SEQUENCE public.character_production_skills_id_seq;
DROP TABLE public.character_production_skill;
DROP SEQUENCE public.character_id_seq;
DROP SEQUENCE public.character_general_skills_id_seq;
DROP TABLE public.character_general_skill;
DROP SEQUENCE public.character_combat_actions_id_seq;
DROP TABLE public.character_combat_action;
DROP TABLE public."character";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: character; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."character" (
    id integer NOT NULL,
    user_id integer,
    build_total integer,
    character_name character(255),
    race_description_id integer,
    class_description_id integer,
    background text,
    description character varying(255),
    image character varying,
    class_type integer,
    race integer
);


ALTER TABLE public."character" OWNER TO postgres;

--
-- Name: character_combat_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.character_combat_action (
    id integer NOT NULL,
    action_type integer,
    action_total integer,
    character_id integer
);


ALTER TABLE public.character_combat_action OWNER TO postgres;

--
-- Name: character_combat_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.character_combat_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.character_combat_actions_id_seq OWNER TO postgres;

--
-- Name: character_combat_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.character_combat_actions_id_seq OWNED BY public.character_combat_action.id;


--
-- Name: character_general_skill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.character_general_skill (
    id integer NOT NULL,
    character_id integer NOT NULL,
    skill_id integer NOT NULL
);


ALTER TABLE public.character_general_skill OWNER TO postgres;

--
-- Name: character_general_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.character_general_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.character_general_skills_id_seq OWNER TO postgres;

--
-- Name: character_general_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.character_general_skills_id_seq OWNED BY public.character_general_skill.id;


--
-- Name: character_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.character_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.character_id_seq OWNER TO postgres;

--
-- Name: character_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.character_id_seq OWNED BY public."character".id;


--
-- Name: character_production_skill; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.character_production_skill (
    id integer NOT NULL,
    production_type integer,
    production_total integer,
    character_id integer
);


ALTER TABLE public.character_production_skill OWNER TO postgres;

--
-- Name: character_production_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.character_production_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.character_production_skills_id_seq OWNER TO postgres;

--
-- Name: character_production_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.character_production_skills_id_seq OWNED BY public.character_production_skill.id;


--
-- Name: character_spellcasting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.character_spellcasting (
    id integer NOT NULL,
    character_id integer,
    spellcasting_description_id integer,
    spell_column_order integer,
    spell_level_total integer
);


ALTER TABLE public.character_spellcasting OWNER TO postgres;

--
-- Name: character_spellcasting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.character_spellcasting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.character_spellcasting_id_seq OWNER TO postgres;

--
-- Name: character_spellcasting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.character_spellcasting_id_seq OWNED BY public.character_spellcasting.id;


--
-- Name: class_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_description (
    id integer NOT NULL,
    class_name character(32),
    class_description text
);


ALTER TABLE public.class_description OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.classes_id_seq OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.class_description.id;


--
-- Name: combat_action_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.combat_action_description (
    id integer NOT NULL,
    action_name character(32),
    "action_description" text,
    action_description text
);


ALTER TABLE public.combat_action_description OWNER TO postgres;

--
-- Name: combat_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.combat_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.combat_actions_id_seq OWNER TO postgres;

--
-- Name: combat_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.combat_actions_id_seq OWNED BY public.combat_action_description.id;


--
-- Name: general_skill_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.general_skill_description (
    id integer NOT NULL,
    skill_name character(255),
    skill_cost integer,
    skill_description text,
    restricted_status integer
);


ALTER TABLE public.general_skill_description OWNER TO postgres;

--
-- Name: general_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.general_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.general_skills_id_seq OWNER TO postgres;

--
-- Name: general_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.general_skills_id_seq OWNED BY public.general_skill_description.id;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: production_skill_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_skill_description (
    id integer NOT NULL,
    name character(32),
    description text
);


ALTER TABLE public.production_skill_description OWNER TO postgres;

--
-- Name: production_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.production_skills_id_seq OWNER TO postgres;

--
-- Name: production_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_skills_id_seq OWNED BY public.production_skill_description.id;


--
-- Name: race_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.race_description (
    id integer NOT NULL,
    race_name character(255),
    race_description text
);


ALTER TABLE public.race_description OWNER TO postgres;

--
-- Name: races_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.races_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.races_id_seq OWNER TO postgres;

--
-- Name: races_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.races_id_seq OWNED BY public.race_description.id;


--
-- Name: spellcasting_description; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.spellcasting_description (
    id integer NOT NULL,
    name character(255),
    description text
);


ALTER TABLE public.spellcasting_description OWNER TO postgres;

--
-- Name: spellcasting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.spellcasting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spellcasting_id_seq OWNER TO postgres;

--
-- Name: spellcasting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.spellcasting_id_seq OWNED BY public.spellcasting_description.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    username character varying(32) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    password character(255) NOT NULL,
    create_date date,
    account_active boolean,
    gob_total integer,
    account_role integer,
    id integer NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: character id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character" ALTER COLUMN id SET DEFAULT nextval('public.character_id_seq'::regclass);


--
-- Name: character_combat_action id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_combat_action ALTER COLUMN id SET DEFAULT nextval('public.character_combat_actions_id_seq'::regclass);


--
-- Name: character_general_skill id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_general_skill ALTER COLUMN id SET DEFAULT nextval('public.character_general_skills_id_seq'::regclass);


--
-- Name: character_production_skill id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_production_skill ALTER COLUMN id SET DEFAULT nextval('public.character_production_skills_id_seq'::regclass);


--
-- Name: character_spellcasting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_spellcasting ALTER COLUMN id SET DEFAULT nextval('public.character_spellcasting_id_seq'::regclass);


--
-- Name: class_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_description ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: combat_action_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.combat_action_description ALTER COLUMN id SET DEFAULT nextval('public.combat_actions_id_seq'::regclass);


--
-- Name: general_skill_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.general_skill_description ALTER COLUMN id SET DEFAULT nextval('public.general_skills_id_seq'::regclass);


--
-- Name: production_skill_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_skill_description ALTER COLUMN id SET DEFAULT nextval('public.production_skills_id_seq'::regclass);


--
-- Name: race_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.race_description ALTER COLUMN id SET DEFAULT nextval('public.races_id_seq'::regclass);


--
-- Name: spellcasting_description id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spellcasting_description ALTER COLUMN id SET DEFAULT nextval('public.spellcasting_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: character; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."character" (id, user_id, build_total, character_name, race_description_id, class_description_id, background, description, image, class_type, race) FROM stdin;
\.
COPY public."character" (id, user_id, build_total, character_name, race_description_id, class_description_id, background, description, image, class_type, race) FROM '$$PATH$$/2246.dat';

--
-- Data for Name: character_combat_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.character_combat_action (id, action_type, action_total, character_id) FROM stdin;
\.
COPY public.character_combat_action (id, action_type, action_total, character_id) FROM '$$PATH$$/2248.dat';

--
-- Name: character_combat_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.character_combat_actions_id_seq', 1, false);


--
-- Data for Name: character_general_skill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.character_general_skill (id, character_id, skill_id) FROM stdin;
\.
COPY public.character_general_skill (id, character_id, skill_id) FROM '$$PATH$$/2254.dat';

--
-- Name: character_general_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.character_general_skills_id_seq', 1, false);


--
-- Name: character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.character_id_seq', 1, false);


--
-- Data for Name: character_production_skill; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.character_production_skill (id, production_type, production_total, character_id) FROM stdin;
\.
COPY public.character_production_skill (id, production_type, production_total, character_id) FROM '$$PATH$$/2250.dat';

--
-- Name: character_production_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.character_production_skills_id_seq', 1, false);


--
-- Data for Name: character_spellcasting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.character_spellcasting (id, character_id, spellcasting_description_id, spell_column_order, spell_level_total) FROM stdin;
\.
COPY public.character_spellcasting (id, character_id, spellcasting_description_id, spell_column_order, spell_level_total) FROM '$$PATH$$/2262.dat';

--
-- Name: character_spellcasting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.character_spellcasting_id_seq', 1, false);


--
-- Data for Name: class_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_description (id, class_name, class_description) FROM stdin;
\.
COPY public.class_description (id, class_name, class_description) FROM '$$PATH$$/2244.dat';

--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.classes_id_seq', 1, false);


--
-- Data for Name: combat_action_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.combat_action_description (id, action_name, "action_description", action_description) FROM stdin;
\.
COPY public.combat_action_description (id, action_name, "action_description", action_description) FROM '$$PATH$$/2252.dat';

--
-- Name: combat_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.combat_actions_id_seq', 1, false);


--
-- Data for Name: general_skill_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.general_skill_description (id, skill_name, skill_cost, skill_description, restricted_status) FROM stdin;
\.
COPY public.general_skill_description (id, skill_name, skill_cost, skill_description, restricted_status) FROM '$$PATH$$/2256.dat';

--
-- Name: general_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.general_skills_id_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- Data for Name: production_skill_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_skill_description (id, name, description) FROM stdin;
\.
COPY public.production_skill_description (id, name, description) FROM '$$PATH$$/2258.dat';

--
-- Name: production_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_skills_id_seq', 1, false);


--
-- Data for Name: race_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.race_description (id, race_name, race_description) FROM stdin;
\.
COPY public.race_description (id, race_name, race_description) FROM '$$PATH$$/2242.dat';

--
-- Name: races_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.races_id_seq', 1, false);


--
-- Data for Name: spellcasting_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spellcasting_description (id, name, description) FROM stdin;
\.
COPY public.spellcasting_description (id, name, description) FROM '$$PATH$$/2260.dat';

--
-- Name: spellcasting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.spellcasting_id_seq', 1, false);


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (username, first_name, last_name, email, password, create_date, account_active, gob_total, account_role, id) FROM stdin;
\.
COPY public."user" (username, first_name, last_name, email, password, create_date, account_active, gob_total, account_role, id) FROM '$$PATH$$/2264.dat';

--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 8, true);


--
-- Name: character_combat_action character_combat_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_combat_action
    ADD CONSTRAINT character_combat_actions_pkey PRIMARY KEY (id);


--
-- Name: character_general_skill character_general_skill_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_general_skill
    ADD CONSTRAINT character_general_skill_pkey PRIMARY KEY (id);


--
-- Name: character character_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT character_pkey PRIMARY KEY (id);


--
-- Name: character_production_skill character_production_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_production_skill
    ADD CONSTRAINT character_production_skills_pkey PRIMARY KEY (id);


--
-- Name: character_spellcasting character_spellcasting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_spellcasting
    ADD CONSTRAINT character_spellcasting_pkey PRIMARY KEY (id);


--
-- Name: class_description class_description_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_description
    ADD CONSTRAINT class_description_pkey PRIMARY KEY (id);


--
-- Name: combat_action_description combat_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.combat_action_description
    ADD CONSTRAINT combat_actions_pkey PRIMARY KEY (id);


--
-- Name: general_skill_description general_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.general_skill_description
    ADD CONSTRAINT general_skills_pkey PRIMARY KEY (id);


--
-- Name: production_skill_description production_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_skill_description
    ADD CONSTRAINT production_skills_pkey PRIMARY KEY (id);


--
-- Name: race_description race_description_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.race_description
    ADD CONSTRAINT race_description_pkey PRIMARY KEY (id);


--
-- Name: spellcasting_description spellcasting_primary_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spellcasting_description
    ADD CONSTRAINT spellcasting_primary_key PRIMARY KEY (id);


--
-- Name: user user_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_id_pkey PRIMARY KEY (id);


--
-- Name: character_general_skill character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_general_skill
    ADD CONSTRAINT character_id_fkey FOREIGN KEY (character_id) REFERENCES public."character"(id);


--
-- Name: character_spellcasting character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_spellcasting
    ADD CONSTRAINT character_id_fkey FOREIGN KEY (character_id) REFERENCES public."character"(id);


--
-- Name: character_combat_action character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_combat_action
    ADD CONSTRAINT character_id_fkey FOREIGN KEY (character_id) REFERENCES public."character"(id);


--
-- Name: character_production_skill character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_production_skill
    ADD CONSTRAINT character_id_fkey FOREIGN KEY (character_id) REFERENCES public."character"(id);


--
-- Name: character class_description_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT class_description_id_fkey FOREIGN KEY (class_description_id) REFERENCES public.class_description(id);


--
-- Name: character_combat_action combat_action_description_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_combat_action
    ADD CONSTRAINT combat_action_description_fkey FOREIGN KEY (action_type) REFERENCES public.combat_action_description(id);


--
-- Name: character_general_skill general_skill_description_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_general_skill
    ADD CONSTRAINT general_skill_description_id_fkey FOREIGN KEY (skill_id) REFERENCES public.general_skill_description(id);


--
-- Name: character_production_skill production_skill_description_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_production_skill
    ADD CONSTRAINT production_skill_description_id_fkey FOREIGN KEY (production_type) REFERENCES public.production_skill_description(id);


--
-- Name: character race_description_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT race_description_id_fkey FOREIGN KEY (race_description_id) REFERENCES public.race_description(id);


--
-- Name: character_spellcasting spellcasting_description_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.character_spellcasting
    ADD CONSTRAINT spellcasting_description_id_fkey FOREIGN KEY (spellcasting_description_id) REFERENCES public.spellcasting_description(id);


--
-- Name: character user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

